function init() {
    document.querySelector('#logar').addEventListener('click', logar);
}

function logar() {
    var email = document.querySelector('#usuario').value, senha = document.querySelector('#senha').value, formData = {};

    if (email && senha) {
        formData['email'] = email;
        formData['senha'] = senha;

        var http = new XMLHttpRequest();
        http.open('POST', 'http://localhost:8080/ControleReservatorio-war/Login', true);
        http.addEventListener("load", function () {
            var msg = JSON.parse(http.responseText).mensagem;
            if (msg === 'Não foi localizado um usuário com este email e senha.') {
                alert(msg);
            }else{
                msg = JSON.parse(msg)[0];
                localStorage.setItem('codigo', msg.codigo);
                localStorage.setItem('nome', msg.nome);
                alert('Logado com sucesso!');
                window.location.href = 'index.html';
            }
        });
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        http.send(JSON.stringify(formData));
    } else {
        alert('Informe o e-mail e senha.');
    }
}

init();


