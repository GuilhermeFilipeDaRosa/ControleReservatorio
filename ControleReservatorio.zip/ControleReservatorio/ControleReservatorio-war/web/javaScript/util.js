function isLogado() {
    if (localStorage.getItem('codigo') && localStorage.getItem('nome')) {
        return true;
    } else {
        limpaLocalStorage();
        return false;
    }
}

function requisicaoHttp(metodo, endereco, assincrona, callback) {
    var http = new XMLHttpRequest();
    http.open(metodo, endereco, assincrona);
    http.addEventListener("load", function () {
        callback(http.responseText);
    });
    http.send();
}

function limpaLocalStorage() {
    localStorage.setItem('codigo', '');
    localStorage.setItem('nome', '');
}

function mostraUsuario(){
    if(isLogado()){
        document.querySelector('#entrarCadastrar').setAttribute('class', 'none');
        document.querySelector('#userIdentificacao').setAttribute('class', '');
        document.querySelector('#nomeUsuario').innerText  = localStorage.getItem('nome');
    }
}

function sair(){
    limpaLocalStorage();
    window.location.href = 'index.html';
}
