function init() {
    if (isLogado()) {
        var http = new XMLHttpRequest(), formData = {}, campo = document.querySelector('#PETS'), aux = "";
        formData["usuario"] = localStorage.getItem('codigo');

        http.open("POST", "http://localhost:8080/ControleReservatorio-war/Pet", true);
        http.addEventListener("load", function () {
            var opcoes = JSON.parse(JSON.parse(http.responseText).pets);
            for (var i = 0; i < opcoes.length; i++) {
                aux += "<option value=\""+opcoes[i].cpet+"\">"+opcoes[i].pet+"</option>";
            }
            campo.innerHTML += aux; 
        });
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        http.send(JSON.stringify(formData));

        document.querySelector("#salvar").addEventListener("click", salvaControle);
    } else {
        window.location.href = "entrar.html";
        alert('Voce precisa estar logado para alterar os controles');
    }
}

function salvaControle() {
    var pagua = document.querySelector("#PAGUA").value,
            pracao = document.querySelector("#PRACAO").value,
            formData = {};

    if (!pagua || !pracao) {
        alert('Você não preencheu todas as informações');
        return;
    }

    formData["pagua"] = pagua;
    formData["pracao"] = pracao;

    var http = new XMLHttpRequest();
    http.open("POST", "http://localhost:8080/ControleReservatorio-war/Controles", true);
    http.addEventListener("load", function () {
        var msg = JSON.parse(http.responseText).mensagem;
        alert(msg);
    });
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.send(JSON.stringify(formData));
}

init();