function init() {
    document.querySelector("#enviar").addEventListener("click", cadastraUsuario);
}

function cadastraUsuario() {
    var form = document.querySelector("#form"),
            formData = {},
            data = form.nascimento.value.split("-"),
            senha = form.senha.value;

    if (form.nome.value === '' || !data || form.cpf.value === '' || form.cep.value === '' || form.endereco.value === ''
            || form.numero.value === '' || form.bairro.value === '' || form.uf.value === ''
            || form.cidade.value === '' || form.telefone.value === '' || form.email.value === '' || form.complemento.value === ''
            || form.senhaConfirma.value === '') {
        alert('Você não preencheu todas as informações');
        return;
    }

    if (senha !== form.senhaConfirma.value) {
        alert("As senhas não estão iguais", "Aviso");
        return;
    }

    formData["nome"] = form.nome.value;
    formData["data_nascimento"] = data[2] + '/' + data[1] + '/' + data[0];
    formData["cpf"] = form.cpf.value;
    formData["cep"] = form.cep.value;
    formData["endereco"] = form.endereco.value;
    formData["numero"] = Number(form.numero.value);
    formData["complemento"] = form.complemento.value;
    formData["bairro"] = form.bairro.value;
    formData["estado"] = form.uf.value;
    formData["cidade"] = form.cidade.value;
    formData["telefone"] = form.telefone.value;
    formData["email"] = form.email.value;
    formData["senha"] = senha;

    var http = new XMLHttpRequest();
    http.open("POST", "http://localhost:8080/ControleReservatorio-war/Cadastrar", true);
    http.addEventListener("load", function () {
        var msg = JSON.parse(http.responseText).mensagem;
        alert(msg);
        if (msg === "Cadastrado com sucesso!") {
            window.location.href = "entrar.html";
        }
    });
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.send(JSON.stringify(formData));
}
init();