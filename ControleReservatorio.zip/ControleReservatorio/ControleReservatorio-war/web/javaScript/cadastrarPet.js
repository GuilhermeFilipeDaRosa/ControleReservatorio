
function init() {
    mostraUsuario();
    document.querySelector('#cadastra').addEventListener('click', cadastrarPet);
    document.querySelector('#sair').addEventListener('click', desloga);
}

function desloga() {
    sair();
}

function cadastrarPet() {
    var form = document.querySelector("#form"), data = form.nascimento.value.split("-"),
            formData = {};

    if (isLogado()) {
        if (form.nome.value === ''
                || form.raca.value === '' || form.peso.value === '' || !data) {
            alert('Você não preencheu todas as informações');
            return;
        }

        formData["nome"] = form.nome.value;
        formData["data_nascimento"] = data[2] + '/' + data[1] + '/' + data[0];
        formData["raca"] = form.raca.value;
        formData["peso"] = form.peso.value;
        formData["cusuario"] = localStorage.getItem('codigo');

        var http = new XMLHttpRequest();
        http.open("POST", "http://localhost:8080/ControleReservatorio-war/CadastrarPet", true);
        http.addEventListener("load", function () {
            var msg = JSON.parse(http.responseText).mensagem;
            alert(msg);
            if (msg === "Cadastrado com sucesso!") {
                window.location.href = "cadastrarPet.html";
            }
        });
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        http.send(JSON.stringify(formData));
    } else {
        alert('Você precisa estar logado para cadastrar um pet.');
        window.location.href = 'entrar.html';
    }
}

init();


