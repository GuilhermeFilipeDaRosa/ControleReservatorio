/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author guilherme
 */
public class Pet extends HttpServlet {

    private Connection retornaConnection() {
        try {
            return ConnectionUtil.getConnection();
        } catch (Exception ex) {
            Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            response.setContentType("application/json");

            PrintWriter saida = response.getWriter();
            JsonObject retorno = null, json;
            String usuario, content, dados = null, SQL;
            Connection connection = retornaConnection();
            BufferedReader leitor = new BufferedReader(
                    new InputStreamReader(request.getInputStream(), "UTF-8"));
            PreparedStatement p;
            ResultSet rs;

            content = leitor.lines().collect(Collectors.joining());
            JsonReader reader = Json.createReader(new StringReader(content));
            JsonObject form = reader.readObject();

            usuario = form.getJsonString("usuario").getString();

            SQL = new StringBuilder("SELECT PET.CPET, PET.NOME "
            ).append(" FROM PET "
            ).append(" WHERE PET.CUSUARIO = ? "
            ).append(" ORDER BY PET.CPET").toString();

            p = connection.prepareStatement(SQL);
            p.setInt(1, Integer.parseInt(usuario));
            rs = p.executeQuery();

            while (rs.next()) {
                if (dados != null) {
                    dados += ",";
                }

                json = Json.createObjectBuilder()
                        .add("cpet", rs.getInt("CPET"))
                        .add("pet", rs.getString("NOME")).build();
                if (dados != null) {
                    dados += json.toString();
                } else {
                    dados = json.toString();
                }
            }

            rs.close();
            p.close();

            retorno = Json.createObjectBuilder()
                    .add("pets", "[" + dados + "]").build();

            saida.write(retorno.toString());
        } catch (SQLException ex) {
            Logger.getLogger(Controles.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
