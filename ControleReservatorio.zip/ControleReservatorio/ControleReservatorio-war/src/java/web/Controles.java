/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author guilherme
 */
public class Controles extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("application/json");
        PrintWriter saida = response.getWriter();

        String pagua, pracao, content;

        Connection connection = retornaConnection();

        BufferedReader leitor = new BufferedReader(
                new InputStreamReader(request.getInputStream(), "UTF-8"));

        content = leitor.lines().collect(Collectors.joining());

        JsonReader reader = Json.createReader(new StringReader(content));
        JsonObject form = reader.readObject();

        pagua = form.getJsonString("nome").getString();
        pracao = form.getJsonString("data_nascimento").getString();

        String retorno = "";

        if (retorno.equals("")) {

            String SQL = new StringBuilder("INSERT INTO CONTROLES(PAGUA, PRACAO) VALUES(?, ?)").toString();
            try {
                PreparedStatement p = null;
                try {
                    p = connection.prepareStatement(SQL);
                } catch (SQLException ex) {
                    Logger.getLogger(Controles.class.getName()).log(Level.SEVERE, null, ex);
                }
                p.setDouble(1, Double.parseDouble(pagua));
                p.setDouble(2, Double.parseDouble(pracao));
                p.execute();
            } catch (SQLException ex) {
                try {
                    throw new Exception(ex);
                } catch (Exception ex1) {
                    Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex1);
                }

                retorno = "Alterado com sucesso!";
            }

            JsonObject json = Json.createObjectBuilder()
                    .add("mensagem", retorno)
                    .build();

            saida.write(json.toString());
        }

    }

    private Connection retornaConnection() {
        try {
            return ConnectionUtil.getConnection();
        } catch (Exception ex) {
            Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
