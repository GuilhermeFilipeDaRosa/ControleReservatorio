/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author guilherme
 */
public class Cadastrar extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("application/json");
        PrintWriter saida = response.getWriter();

        String nome, data, cpf, cep, endereco, complemento, bairro, estado, cidade, telefone, email, senha, content;
        int numero;
        Connection connection = retornaConnection();

        BufferedReader leitor = new BufferedReader(
                new InputStreamReader(request.getInputStream(), "UTF-8"));

        content = leitor.lines().collect(Collectors.joining());

        JsonReader reader = Json.createReader(new StringReader(content));
        JsonObject form = reader.readObject();

        nome = form.getJsonString("nome").getString();
        data = form.getJsonString("data_nascimento").getString();
        cpf = form.getJsonString("cpf").getString();
        cep = form.getJsonString("cep").getString();
        endereco = form.getJsonString("endereco").getString();
        numero = form.getJsonNumber("numero").intValue();
        complemento = form.getJsonString("complemento").getString();
        bairro = form.getJsonString("bairro").getString();
        estado = form.getJsonString("estado").getString();
        cidade = form.getJsonString("cidade").getString();
        telefone = form.getJsonString("telefone").getString();
        email = form.getJsonString("email").getString();
        senha = form.getJsonString("senha").getString();

        String retorno = "";
        try {
            retorno = validaUsuario(cpf, nome, email);
        } catch (Exception ex) {
            Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (retorno.equals("")) {

            String SQL = new StringBuilder("INSERT INTO USUARIO(NOME, DATA_NASCIMENTO, CPF, CEP, ENDERECO, NUMERO, COMPLEMENTO,"
            ).append(" BAIRRO, ESTADO, CIDADE, TELEFONE, EMAIL, SENHA) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").toString();
            try {
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                Date date = format.parse(data);
                PreparedStatement p = connection.prepareStatement(SQL);
                p.setString(1, nome);
                p.setDate(2, new java.sql.Date(date.getTime()));
                p.setString(3, cpf);
                p.setString(4, cep);
                p.setString(5, endereco);
                p.setInt(6, numero);
                p.setString(7, complemento);
                p.setString(8, bairro);
                p.setString(9, estado);
                p.setString(10, cidade);
                p.setString(11, telefone);
                p.setString(12, email);
                p.setString(13, senha);
                p.execute();
            } catch (SQLException ex) {
                try {
                    throw new Exception(ex);
                } catch (Exception ex1) {
                    Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex1);
                }
            } catch (ParseException ex) {
                Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
            }
            retorno = "Cadastrado com sucesso!";
        }

        JsonObject json = Json.createObjectBuilder()
                .add("mensagem", retorno)
                .build();

        saida.write(json.toString());
    }

    private Connection retornaConnection() {
        try {
            return ConnectionUtil.getConnection();
        } catch (Exception ex) {
            Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public String validaUsuario(String cpf, String nome, String email) throws Exception {
        String SQL = "SELECT USUARIO.NOME FROM USUARIO WHERE USUARIO.CPF = ?";
        ResultSet rs;
        PreparedStatement p;
        try {
            p = retornaConnection().prepareStatement(SQL);
            p.setString(1, cpf);
            rs = p.executeQuery();
            if (rs.next()) {
                return "Já existe um usuário cadastrado com este cpf.";
            }

            SQL = "SELECT USUARIO.NOME FROM USUARIO WHERE USUARIO.NOME = ?";
            p = retornaConnection().prepareStatement(SQL);
            p.setString(1, nome);
            rs = p.executeQuery();
            if (rs.next()) {
                return "Já existe um usuário cadastrado com este nome.";
            }

            SQL = "SELECT USUARIO.NOME FROM USUARIO WHERE USUARIO.EMAIL = ?";
            p = retornaConnection().prepareStatement(SQL);
            p.setString(1, email);
            rs = p.executeQuery();
            if (rs.next()) {
                return "Já existe um usuário cadastrado com este e-mail.";
            }
        } catch (SQLException ex) {
            throw new Exception(ex);
        }

        return "";
    }
}
