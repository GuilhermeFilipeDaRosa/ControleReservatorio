/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author guilherme
 */
public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter saida = response.getWriter();

        ResultSet rs;
        String email, senha, content;
        Connection connection = retornaConnection();
        JsonObject json, ret, form;
        PreparedStatement p;
        JsonReader reader;
        BufferedReader leitor;

        leitor = new BufferedReader(
                new InputStreamReader(request.getInputStream(), "UTF-8"));

        content = leitor.lines().collect(Collectors.joining());

        reader = Json.createReader(new StringReader(content));
        form = reader.readObject();

        email = form.getJsonString("email").getString();
        senha = form.getJsonString("senha").getString();

        String retorno = "";

        String SQL = "SELECT USUARIO.CUSUARIO, USUARIO.NOME FROM USUARIO WHERE USUARIO.EMAIL = ? AND USUARIO.SENHA = ?";
        try {
            p = connection.prepareStatement(SQL);
            p.setString(1, email);
            p.setString(2, senha);
            rs = p.executeQuery();
            if (rs.next()) {
                json = Json.createObjectBuilder()
                        .add("codigo", rs.getString("CUSUARIO"))
                        .add("nome", rs.getString("NOME")).build();

                retorno = new StringBuilder("[").append(json.toString()).append("]").toString();
            } else {
                retorno = "Não foi localizado um usuário com este email e senha.";
            }
        } catch (SQLException ex) {
            try {
                throw new Exception(ex);
            } catch (Exception ex1) {
                Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

        ret = Json.createObjectBuilder()
                .add("mensagem", retorno)
                .build();

        saida.write(ret.toString());
    }

    private Connection retornaConnection() {
        try {
            return ConnectionUtil.getConnection();
        } catch (Exception ex) {
            Logger.getLogger(Cadastrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
