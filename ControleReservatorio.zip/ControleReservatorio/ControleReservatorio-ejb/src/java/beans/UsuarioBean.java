/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import dao.UsuarioDao;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;

/**
 *
 * @author guilherme
 */
@Stateless
public class UsuarioBean implements UsuarioBeanRemote{
    private final UsuarioDao usuarioDao;

    public UsuarioBean() throws Exception {
        this.usuarioDao = new UsuarioDao();
    }
    
    @Override
    public String cadastraUsuario(int numero, String nome, String data, String cpf, String cep, String endereco, 
            String complemento, String bairro, String estado, 
                    String cidade, String telefone, String email, String senha){
        try {
            return usuarioDao.save(numero, nome, data, cpf, cep, endereco, 
             complemento, bairro, estado, cidade, telefone, email, senha);
        } catch (Exception ex) {
            Logger.getLogger(UsuarioBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Não foi possivel efetuar o cadastro, contatar suporte!";
    }
}
